

u8 Button_Read(u8 portname, u8 pinnumber)
{
    return GPIO_ReadPin(portname,pinnumber);
}
void Button_InitPullUp(u8 portname,u8 pinnumber)
{
    GPIO_InitPort(portname);
    GPIO_SetPinDirection(portname,pinnumber,GPIO_INPUT);
    GPIO_EnablePullUp(portname,pinnumber);
}